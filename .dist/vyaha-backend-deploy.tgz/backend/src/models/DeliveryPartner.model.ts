import mongoose, { Schema, Document } from "mongoose";

export interface IDeliveryPartner extends Document {
  userId: mongoose.Types.ObjectId;
  phone: string;
  name: string;
  email?: string;
  dateOfBirth?: Date;
  address?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  termsAcceptedAt?: Date;
  vehicleType: string;
  vehicleNumber?: string;
  licenseNumber?: string;
  profilePhotoUrl?: string;
  reviewComment?: string;
  suspensionType?: "TEMPORARY" | "PERMANENT" | null;
  suspendedUntil?: Date | null;
  suspendedAt?: Date | null;
  documents?: {
    aadhaarNumber?: string;
    aadhaarFrontUrl?: string;
    aadhaarBackUrl?: string;
    aadhaarUrl?: string;
    aadhaarVerified?: boolean;
    aadhaarVerifiedAt?: Date | null;
    aadhaarName?: string;
    aadhaarMasked?: string;
    aadhaarOtpTxnId?: string;
    aadhaarShareCode?: string;
    nameLocked?: boolean;
    panNumber?: string;
    panFrontUrl?: string;
    panUrl?: string;
    panVerified?: boolean;
    panVerifiedAt?: Date | null;
    panName?: string;
    panSkipped?: boolean;
    selfiePhotoUrl?: string;
    drivingLicenseFrontUrl?: string;
    drivingLicenseBackUrl?: string;
    drivingLicenseUrl?: string;
    vehicleRcFrontUrl?: string;
    vehicleRcBackUrl?: string;
    vehicleRcUrl?: string;
    insuranceUrl?: string;
    bankDocumentType?: "cheque" | "passbook" | "statement" | "";
    bankAccountHolderName?: string;
    cancelledChequeUrl?: string;
    bankPassbookUrl?: string;
    bankStatementUrl?: string;
    bankAccountNumber?: string;
    bankIfsc?: string;
    bankUpiId?: string;
    bankVerificationStatus?: "PENDING" | "VERIFIED" | "REJECTED" | "";
    bankReviewComment?: string;
    bankDetailsSkipped?: boolean;
    kycProvider?: string;
    submittedAt?: Date;
    isComplete?: boolean;
    reuploadFlags?: Record<string, boolean>;
    reuploadNotes?: string;
  };
  isAvailable: boolean;
  status: "PENDING" | "VERIFIED" | "ACTIVE" | "REJECTED" | "SUSPENDED" | "INACTIVE";
  totalDeliveries: number;
  totalEarnings: number;
  cashBalance: number;
  pendingDepositAmount: number;
  lastCashActivityAt?: Date;
  lastCashActivityType?: string;
  currentLocation?: {
    type: string;
    coordinates: [number, number]; // [longitude, latitude]
  };
  rating: number;
  ratingCount: number;
  notifications?: {
    jobAlerts?: boolean;
    payoutAlerts?: boolean;
    promotionAlerts?: boolean;
    offerAlerts?: boolean;
    vibrationEnabled?: boolean;
  };
  createdAt: Date;
  updatedAt: Date;
}

const DeliveryPartnerSchema = new Schema<IDeliveryPartner>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
      unique: true
    },
    phone: {
      type: String,
      required: true,
      unique: true
    },
    name: {
      type: String,
      required: true
    },
    email: {
      type: String
    },
    dateOfBirth: {
      type: Date,
      default: null
    },
    address: {
      type: String,
      default: ""
    },
    emergencyContactName: {
      type: String,
      default: ""
    },
    emergencyContactPhone: {
      type: String,
      default: ""
    },
    termsAcceptedAt: {
      type: Date,
      default: null
    },
    vehicleType: {
      type: String,
      enum: ["Bike", "Cycle", "Bicycle", "Scooter", "Motorcycle", "EV", "Car"],
      default: "Bike"
    },
    vehicleNumber: {
      type: String
    },
    licenseNumber: {
      type: String
    },
    profilePhotoUrl: {
      type: String,
      default: ""
    },
    reviewComment: {
      type: String,
      default: ""
    },
    suspensionType: {
      type: String,
      enum: ["TEMPORARY", "PERMANENT"],
      default: null
    },
    suspendedUntil: {
      type: Date,
      default: null
    },
    suspendedAt: {
      type: Date,
      default: null
    },
    documents: {
      aadhaarNumber: { type: String, default: "" },
      aadhaarFrontUrl: { type: String, default: "" },
      aadhaarBackUrl: { type: String, default: "" },
      aadhaarUrl: { type: String, default: "" },
      aadhaarVerified: { type: Boolean, default: false },
      aadhaarVerifiedAt: { type: Date, default: null },
      aadhaarName: { type: String, default: "" },
      aadhaarMasked: { type: String, default: "" },
      aadhaarOtpTxnId: { type: String, default: "" },
      aadhaarShareCode: { type: String, default: "" },
      nameLocked: { type: Boolean, default: false },
      panNumber: { type: String, default: "" },
      panFrontUrl: { type: String, default: "" },
      panUrl: { type: String, default: "" },
      panVerified: { type: Boolean, default: false },
      panVerifiedAt: { type: Date, default: null },
      panName: { type: String, default: "" },
      panSkipped: { type: Boolean, default: false },
      selfiePhotoUrl: { type: String, default: "" },
      drivingLicenseFrontUrl: { type: String, default: "" },
      drivingLicenseBackUrl: { type: String, default: "" },
      drivingLicenseUrl: { type: String, default: "" },
      vehicleRcFrontUrl: { type: String, default: "" },
      vehicleRcBackUrl: { type: String, default: "" },
      vehicleRcUrl: { type: String, default: "" },
      insuranceUrl: { type: String, default: "" },
      bankDocumentType: { type: String, enum: ["cheque", "passbook", "statement", ""], default: "" },
      bankAccountHolderName: { type: String, default: "" },
      cancelledChequeUrl: { type: String, default: "" },
      bankPassbookUrl: { type: String, default: "" },
      bankStatementUrl: { type: String, default: "" },
      bankAccountNumber: { type: String, default: "" },
      bankIfsc: { type: String, default: "" },
      bankUpiId: { type: String, default: "" },
      bankVerificationStatus: {
        type: String,
        enum: ["PENDING", "VERIFIED", "REJECTED", ""],
        default: ""
      },
      bankReviewComment: { type: String, default: "" },
      bankDetailsSkipped: { type: Boolean, default: false },
      kycProvider: { type: String, default: "" },
      submittedAt: { type: Date, default: null },
      isComplete: { type: Boolean, default: false },
      reuploadFlags: {
        profilePhotoUrl: { type: Boolean, default: false },
        aadhaarFrontUrl: { type: Boolean, default: false },
        aadhaarBackUrl: { type: Boolean, default: false },
        panFrontUrl: { type: Boolean, default: false },
        selfiePhotoUrl: { type: Boolean, default: false },
        drivingLicenseFrontUrl: { type: Boolean, default: false },
        drivingLicenseBackUrl: { type: Boolean, default: false },
        vehicleRcFrontUrl: { type: Boolean, default: false },
        vehicleRcBackUrl: { type: Boolean, default: false },
        insuranceUrl: { type: Boolean, default: false },
        bankProofUrl: { type: Boolean, default: false }
      },
      reuploadNotes: { type: String, default: "" }
    },
    isAvailable: {
      type: Boolean,
      default: true
    },
    status: {
      type: String,
      enum: ["PENDING", "VERIFIED", "ACTIVE", "REJECTED", "SUSPENDED", "INACTIVE"],
      default: "PENDING"
    },
    totalDeliveries: {
      type: Number,
      default: 0
    },
    totalEarnings: {
      type: Number,
      default: 0
    },
    cashBalance: {
      type: Number,
      default: 0,
      min: 0
    },
    pendingDepositAmount: {
      type: Number,
      default: 0,
      min: 0
    },
    lastCashActivityAt: {
      type: Date,
      default: null
    },
    lastCashActivityType: {
      type: String,
      default: ""
    },
    currentLocation: {
      type: {
        type: String,
        enum: ["Point"],
        default: "Point"
      },
      coordinates: {
        type: [Number],
        default: [0, 0]
      }
    },
    rating: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    ratingCount: {
      type: Number,
      default: 0
    },
    notifications: {
      jobAlerts: { type: Boolean, default: true },
      payoutAlerts: { type: Boolean, default: true },
      promotionAlerts: { type: Boolean, default: false },
      offerAlerts: { type: Boolean, default: false },
      vibrationEnabled: { type: Boolean, default: true }
    }
  },
  {
    timestamps: true
  }
);

// Create geospatial index for location queries
DeliveryPartnerSchema.index({ currentLocation: "2dsphere" });

const DeliveryPartner = mongoose.model<IDeliveryPartner>(
  "DeliveryPartner",
  DeliveryPartnerSchema
);

export default DeliveryPartner;
