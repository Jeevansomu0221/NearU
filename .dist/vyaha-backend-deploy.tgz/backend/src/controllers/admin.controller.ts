import { Request, Response } from "express";
import mongoose from "mongoose";
import Order from "../models/Order.model";
import Partner from "../models/Partner.model";
import User from "../models/User.model";
import {
  notifyCustomerOrderStatus,
  notifyDeliveryJobReady,
  notifyPartnerApplicationStatus,
  notifyPartnerDeliveryStatus,
  notifyPartnerDocumentReupload
} from "../services/notification.service";
import { clearSuspensionFields, type SuspensionType } from "../utils/suspension.util";

// Create a type for authenticated requests
interface AuthRequest extends Request {
  user?: {
    id: string;
    phone: string;
    role: string;
    partnerId?: string;
  };
}

const isAdmin = (req: AuthRequest, res: Response): boolean => {
  if (!req.user || req.user.role !== "admin") {
    res.status(403).json({
      success: false,
      message: "Admin access only"
    });
    return false;
  }
  return true;
};

/**
 * GET ALL ORDERS (ADMIN)
 */
export const getAllOrders = async (req: AuthRequest, res: Response) => {
  if (!isAdmin(req, res)) return;

  try {
    const orders = await Order.find()
      .sort({ createdAt: -1 })
      .populate("customerId partnerId deliveryPartnerId");

    res.json({
      success: true,
      data: orders
    });
  } catch (error: any) {
    console.error("Error getting all orders:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch orders"
    });
  }
};

/**
 * GET PARTNER REQUESTS (ADMIN)
 * Gets all partners with their status
 */
export const getPartnerRequests = async (req: AuthRequest, res: Response) => {
  if (!isAdmin(req, res)) return;

  try {
    const partners = await Partner.find()
      .sort({ createdAt: -1 })
      .populate("userId", "name phone email isActive deletedRoles")
      .select(
        "ownerName restaurantName shopName phone ownerPhone restaurantPhone address category status isOpen hasCompletedSetup createdAt documents approvedAt rejectionReason suspensionType suspendedUntil suspendedAt"
      );

    const data = partners.map((partner) => {
      const plain = partner.toObject();
      const user = plain.userId as
        | { isActive?: boolean; deletedRoles?: string[]; name?: string; phone?: string; email?: string }
        | null
        | undefined;
      const restaurantName = String(plain.restaurantName || "");
      const shopName = String(plain.shopName || "");
      const phone = String(plain.phone || "");
      const rejectionReason = String(plain.rejectionReason || "");
      const isDeleted =
        restaurantName === "Deleted Partner" ||
        shopName === "Deleted Partner" ||
        phone.startsWith("deleted_") ||
        /account deleted/i.test(rejectionReason) ||
        user?.isActive === false ||
        Boolean(user?.deletedRoles?.includes("partner"));

      return {
        ...plain,
        isDeleted
      };
    });

    res.json({
      success: true,
      data
    });
  } catch (error: any) {
    console.error("Error getting partner requests:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch partner requests"
    });
  }
};

/**
 * UPDATE PARTNER STATUS (ADMIN)
 * Approve/Reject/Suspend partner
 */
export const updatePartnerStatus = async (req: AuthRequest, res: Response) => {
  if (!isAdmin(req, res)) return;

  try {
    const { partnerId } = req.params;
    const { status, rejectionReason, suspensionType, suspendedUntil, deleteAccount } = req.body;

    // Validate status
    const validStatuses = ["APPROVED", "REJECTED", "SUSPENDED", "PENDING"];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Must be one of: ${validStatuses.join(", ")}`
      });
    }

    if (status === "SUSPENDED" && !String(rejectionReason || "").trim()) {
      return res.status(400).json({
        success: false,
        message: "A suspension reason is required"
      });
    }

    const normalizedSuspensionType = suspensionType as SuspensionType | undefined;
    if (status === "SUSPENDED" && !deleteAccount) {
      if (!normalizedSuspensionType || !["TEMPORARY", "PERMANENT"].includes(normalizedSuspensionType)) {
        return res.status(400).json({
          success: false,
          message: "Suspension type must be TEMPORARY or PERMANENT"
        });
      }

      if (normalizedSuspensionType === "TEMPORARY" && !suspendedUntil) {
        return res.status(400).json({
          success: false,
          message: "suspendedUntil is required for temporary suspensions"
        });
      }
    }

    // Find partner
    const partner = await Partner.findById(partnerId);
    if (!partner) {
      return res.status(404).json({
        success: false,
        message: "Partner not found"
      });
    }

    // Update partner status
    partner.status = status;
    
    if (status === "APPROVED") {
      // Convert string ID to ObjectId if it exists
      if (req.user?.id) {
        partner.approvedBy = new mongoose.Types.ObjectId(req.user.id);
      }
      partner.approvedAt = new Date();
      partner.rejectionReason = undefined;
      clearSuspensionFields(partner);
      
    } else if (status === "REJECTED") {
      partner.rejectionReason = rejectionReason || "Application rejected";
      partner.approvedBy = undefined;
      partner.approvedAt = undefined;
      clearSuspensionFields(partner);
    } else if (status === "SUSPENDED") {
      const reason = String(rejectionReason || (deleteAccount ? "Account deleted by admin" : "Account suspended")).trim();
      partner.rejectionReason = deleteAccount && !/account deleted/i.test(reason)
        ? `${reason} (Account deleted by admin)`
        : reason;
      partner.suspensionType = deleteAccount ? "PERMANENT" : normalizedSuspensionType;
      partner.suspendedAt = new Date();
      partner.suspendedUntil =
        !deleteAccount && normalizedSuspensionType === "TEMPORARY" && suspendedUntil
          ? new Date(suspendedUntil)
          : null;
      partner.isOpen = false;
    }

    await partner.save();

    if (status === "SUSPENDED" && deleteAccount && partner.userId) {
      await User.findByIdAndUpdate(partner.userId, {
        $set: { isActive: false },
        $inc: { sessionVersion: 1 }
      });
    } else if (status === "APPROVED" && partner.userId) {
      await User.findByIdAndUpdate(partner.userId, {
        $set: { isActive: true }
      });
    }

    void notifyPartnerApplicationStatus(partner).catch((error) => {
      console.error("Failed to notify partner status update:", error);
    });

    res.json({
      success: true,
      data: partner,
      message: `Partner status updated to ${status}`
    });
  } catch (error: any) {
    console.error("Error updating partner status:", error);
    res.status(500).json({
      success: false,
      message: "Failed to update partner status"
    });
  }
};

const VALID_REUPLOAD_KEYS = new Set([
  "fssaiUrl",
  "panFrontUrl",
  "aadhaarFrontUrl",
  "gstUrl"
]);

/**
 * REQUEST DOCUMENT RE-UPLOAD (ADMIN)
 * Body: { keys: string[], note?: string, clear?: boolean }
 */
export const requestPartnerDocumentReupload = async (req: AuthRequest, res: Response) => {
  if (!isAdmin(req, res)) return;

  try {
    const { partnerId } = req.params;
    const { keys, note, clear } = req.body as { keys?: string[]; note?: string; clear?: boolean };

    const partner = await Partner.findById(partnerId);
    if (!partner) {
      return res.status(404).json({ success: false, message: "Partner not found" });
    }

    const documents: any = partner.documents || {};
    documents.reuploadFlags = documents.reuploadFlags || {};

    const sanitizedKeys = Array.isArray(keys)
      ? keys.filter((key) => VALID_REUPLOAD_KEYS.has(key))
      : [];

    if (clear) {
      const targetKeys = sanitizedKeys.length ? sanitizedKeys : Array.from(VALID_REUPLOAD_KEYS);
      targetKeys.forEach((key) => {
        documents.reuploadFlags[key] = false;
      });
      if (note !== undefined) {
        documents.reuploadNotes = String(note || "").trim();
      } else if (!sanitizedKeys.length) {
        documents.reuploadNotes = "";
      }
    } else {
      const reuploadNote = String(note || "").trim();
      if (!sanitizedKeys.length) {
        return res.status(400).json({
          success: false,
          message: "Provide at least one document key to request re-upload."
        });
      }
      if (!reuploadNote) {
        return res.status(400).json({
          success: false,
          message: "Provide a reason for the re-upload request."
        });
      }
      sanitizedKeys.forEach((key) => {
        documents.reuploadFlags[key] = true;
      });
      documents.reuploadNotes = reuploadNote;
    }

    partner.documents = documents;
    partner.markModified("documents");
    await partner.save();

    if (!clear) {
      void notifyPartnerDocumentReupload(partner).catch((error) => {
        console.error("Failed to notify partner document re-upload:", error);
      });
    }

    res.json({
      success: true,
      data: {
        reuploadFlags: documents.reuploadFlags,
        reuploadNotes: documents.reuploadNotes
      },
      message: clear ? "Re-upload requirement cleared" : "Re-upload requested"
    });
  } catch (error: any) {
    console.error("Error requesting document re-upload:", error);
    res.status(500).json({ success: false, message: "Failed to update re-upload request" });
  }
};

/**
 * GET PARTNER DETAILS (ADMIN)
 */
export const getPartnerDetails = async (req: AuthRequest, res: Response) => {
  if (!isAdmin(req, res)) return;

  try {
    const { partnerId } = req.params;

    const partner = await Partner.findById(partnerId)
      .populate("userId", "name phone email")
      .populate("approvedBy", "name phone");

    if (!partner) {
      return res.status(404).json({
        success: false,
        message: "Partner not found"
      });
    }

    res.json({
      success: true,
      data: partner
    });
  } catch (error: any) {
    console.error("Error getting partner details:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch partner details"
    });
  }
};

/**
 * GET ORDER DETAILS (ADMIN)
 */
export const getOrderDetails = async (req: AuthRequest, res: Response) => {
  if (!isAdmin(req, res)) return;

  try {
    const { orderId } = req.params;

    const order = await Order.findById(orderId)
      .populate("customerId", "name phone")
      .populate("partnerId", "restaurantName phone address")
      .populate("deliveryPartnerId", "name phone");

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found"
      });
    }

    res.json({
      success: true,
      data: order
    });
  } catch (error: any) {
    console.error("Error getting order details:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch order details"
    });
  }
};

/**
 * UPDATE ORDER STATUS (ADMIN)
 */
export const updateOrderStatus = async (req: AuthRequest, res: Response) => {
  if (!isAdmin(req, res)) return;

  try {
    const { orderId } = req.params;
    const { status } = req.body;

    const validStatuses = [
      "PENDING",
      "CONFIRMED",
      "ACCEPTED",
      "PREPARING",
      "READY",
      "ASSIGNED",
      "PICKED_UP",
      "DELIVERED",
      "CANCELLED",
      "REJECTED"
    ];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Must be one of: ${validStatuses.join(", ")}`
      });
    }

    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found"
      });
    }

    const previousStatus = order.status;
    if (
      status === "DELIVERED" &&
      previousStatus !== "DELIVERED" &&
      order.paymentMethod === "CASH_ON_DELIVERY" &&
      !order.codCollection?.cashLedgerEntryId
    ) {
      return res.status(400).json({
        success: false,
        message: "COD orders must be marked delivered from the rider app so collected cash is recorded."
      });
    }

    order.status = status;
    if (status === "READY" && previousStatus !== "READY") {
      order.deliveryReadyAt = new Date();
    }
    if (status === "DELIVERED" && previousStatus !== "DELIVERED") {
      order.deliveredAt = new Date();
    }
    if (status === "DELIVERED" && order.paymentMethod === "CASH_ON_DELIVERY" && order.paymentStatus === "PAYMENT_PENDING_DELIVERY") {
      order.paymentStatus = "PAID";
    }
    await order.save();

    if (previousStatus !== status) {
      void Promise.all([
        notifyCustomerOrderStatus(order, status),
        status === "READY" && previousStatus !== "READY" ? notifyDeliveryJobReady(order) : Promise.resolve(),
        ["PICKED_UP", "DELIVERED", "CANCELLED"].includes(status)
          ? notifyPartnerDeliveryStatus(order, status)
          : Promise.resolve()
      ]).catch((error) => {
        console.error("Failed to notify admin order status update:", error);
      });
    }

    res.json({
      success: true,
      data: order,
      message: `Order status updated to ${status}`
    });
  } catch (error: any) {
    console.error("Error updating order status:", error);
    res.status(500).json({
      success: false,
      message: "Failed to update order status"
    });
  }
};

/**
 * GET DASHBOARD STATS (ADMIN)
 */
// Fixed getDashboardStats function in admin.controller.ts
/**
 * GET DASHBOARD STATS (ADMIN)
 */
export const getDashboardStats = async (req: AuthRequest, res: Response) => {
  if (!isAdmin(req, res)) return;

  try {
    // Get counts
    const totalOrders = await Order.countDocuments();
    const pendingOrders = await Order.countDocuments({ status: "PENDING" });
    const totalPartners = await Partner.countDocuments();
    const pendingPartners = await Partner.countDocuments({ status: "PENDING" });
    const activePartners = await Partner.countDocuments({ status: "APPROVED", isOpen: true });

    // Get today's date range
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const todayOrders = await Order.countDocuments({
      createdAt: { $gte: today, $lt: tomorrow }
    });

    // Calculate total earnings - use grandTotal field from your Order model
    const deliveredOrders = await Order.find({ status: "DELIVERED" });
    
    let totalEarnings = 0;
    
    deliveredOrders.forEach(order => {
      // Use the grandTotal field from your Order model
      if (order.grandTotal && typeof order.grandTotal === 'number') {
        totalEarnings += order.grandTotal;
      }
    });

    const stats = {
      totalOrders,
      pendingOrders,
      todayOrders,
      totalPartners,
      pendingPartners,
      activePartners,
      totalEarnings,
      today: today.toISOString().split('T')[0]
    };

    res.json({
      success: true,
      data: stats
    });
  } catch (error: any) {
    console.error("Error getting dashboard stats:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch dashboard stats"
    });
  }
};